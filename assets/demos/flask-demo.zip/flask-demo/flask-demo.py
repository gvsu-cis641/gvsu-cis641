from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def index():
  return 'Server Works!'

@app.route('/cis350')
def hello_there():
  return 'Hey there 350 hope you have a gr8 weekend ... m8'
  
@app.route('/greet')
def say_hello():
  return 'Hello from Server'

@app.route('/msg')
def say_msg():
    import random
    msgs = ['hello there', 'hey', 'hello world', 'hello universe']
    random.shuffle(msgs)
    templateData = {
      'message': msgs[0]
    }
    return render_template('msg.html', **templateData)
            

if __name__ == "__main__":
  app.run()
